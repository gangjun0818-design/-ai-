export type Level = "쉬움" | "보통" | "어려움"
export type Difficulty = "easy" | "medium" | "hard"

/** Categories used for the "exclude" filter toggles. */
export type Category = "한식" | "중식" | "일식" | "양식" | "패스트푸드"

/** The 4 categories that can be excluded via the filter toggles. */
export const FILTER_CATEGORIES: Category[] = ["한식", "중식", "양식", "패스트푸드"]

export type Restaurant = {
  campus: "율전" | "명륜"
  name: string
  category: Category
  menu: string
  level: Level
  desc: string
  mapUrl: string
}

export type Campus = "율전" | "명륜"

export const CAMPUS_LABELS: Record<Campus, string> = {
  명륜: "명륜 캠퍼스",
  율전: "율전 캠퍼스",
}

const DIFFICULTY_TO_LEVEL: Record<Difficulty, Level> = {
  easy: "쉬움",
  medium: "보통",
  hard: "어려움",
}

type RawRestaurant = {
  campus: "율전" | "명륜"
  name: string
  category: Category
  menu: string
  difficulty: Difficulty
  desc: string
  map_url: string
}

const RAW: RawRestaurant[] = [
  {
    campus: "율전",
    name: "청년밥상",
    category: "한식",
    menu: "우렁쌈밥 9,000원 / 제육쌈밥 9,000원",
    difficulty: "easy",
    desc: "학생들이 부담 없이 이용하기 좋은 가성비 식당. 혼자 식사하기 편하고 집밥 느낌의 메뉴가 많아 공강 시간 혼밥용으로 추천.",
    map_url:
      "https://map.naver.com/p/search/%EC%B2%AD%EB%85%84%EB%B0%A5%EC%83%81%20%EC%88%98%EC%9B%90%20%EC%9C%A8%EC%A0%84%EB%8F%99",
  },
  {
    campus: "율전",
    name: "기울어진뚝배기 수원성대점",
    category: "한식",
    menu: "일품 돼지국밥 10,000원 / 수육국밥 10,000원",
    difficulty: "easy",
    desc: "국밥 한 그릇으로 빠르게 식사할 수 있어 혼밥에 적합. 따뜻하고 든든한 메뉴를 원하는 학생에게 추천.",
    map_url:
      "https://map.naver.com/p/search/%EA%B8%B0%EC%9A%B8%EC%96%B4%EC%A7%84%EB%9A%9D%EB%B0%B0%EA%B8%B0%20%EC%88%98%EC%9B%90%EC%84%B1%EB%8C%80%EC%A0%90",
  },
  {
    campus: "율전",
    name: "알촌 수원 성균관대점",
    category: "한식",
    menu: "순한알밥 6,000원 / 제육알밥 7,400원",
    difficulty: "easy",
    desc: "가격이 저렴하고 주문 후 비교적 빠르게 먹을 수 있어 학생 혼밥에 매우 적합. 가성비 중심 추천 메뉴로 활용하기 좋음.",
    map_url:
      "https://map.naver.com/p/search/%EC%95%8C%EC%B4%8C%20%EC%88%98%EC%9B%90%20%EC%84%B1%EA%B7%A0%EA%B4%80%EB%8C%80%EC%A0%90",
  },
  {
    campus: "율전",
    name: "서울24시감자탕",
    category: "한식",
    menu: "뼈해장국 10,000원 / 선지해장국 11,000원",
    difficulty: "easy",
    desc: "1인 메뉴인 해장국을 주문하면 혼자서도 부담 없이 이용 가능. 국물류를 선호하거나 포만감 있는 식사를 원하는 경우 추천.",
    map_url:
      "https://map.naver.com/p/search/%EC%84%9C%EC%9A%B824%EC%8B%9C%EA%B0%90%EC%9E%90%ED%83%95%20%EC%9C%A8%EC%A0%84%EB%8F%99",
  },
  {
    campus: "율전",
    name: "영통찌개지존",
    category: "한식",
    menu: "통돼지 김치찌개(중) 17,000원",
    difficulty: "hard",
    desc: "김치찌개와 라면사리 등 푸짐한 식사를 원하는 경우 적합. 1인 혼밥보다는 2인 이상 식사에 더 적합하므로 룰렛 우선순위는 낮게 설정 추천.",
    map_url:
      "https://map.naver.com/p/search/%EC%98%81%ED%86%B5%EC%B0%8C%EA%B0%9C%EC%A7%80%EC%A1%B4%20%EC%9C%A8%EC%A0%84%EB%8F%99",
  },
  {
    campus: "율전",
    name: "일미닭갈비파전",
    category: "한식",
    menu: "닭갈비 / 파전 (1인 약 10,000원대)",
    difficulty: "hard",
    desc: "가성비 있게 닭갈비나 전류를 먹고 싶은 학생에게 적합. 다만 메뉴 특성상 혼밥보다는 친구와 함께 먹을 때 더 추천.",
    map_url:
      "https://map.naver.com/p/search/%EC%9D%BC%EB%AF%B8%EB%8B%AD%EA%B0%88%EB%B9%84%ED%8C%8C%EC%A0%84%20%EC%9C%A8%EC%A0%84%EB%8F%99",
  },
  {
    campus: "율전",
    name: "보배반점 성균관대점",
    category: "중식",
    menu: "짬뽕류 / 미니 탕수육 14,000원",
    difficulty: "easy",
    desc: "짜장·짬뽕 등 1인 메뉴가 있어 혼밥이 가능하고 메뉴 선택이 쉬움. 매장이 비교적 넓고 든든한 중식을 원할 때 추천.",
    map_url:
      "https://map.naver.com/p/search/%EB%B3%B4%EB%B0%B0%EB%B0%98%EC%A0%90%20%EC%84%B1%EA%B7%A0%EA%B4%80%EB%8C%80%EC%A0%90",
  },
  {
    campus: "율전",
    name: "화원루",
    category: "중식",
    menu: "짜장면 7,000원 / 짬뽕 9,000원",
    difficulty: "easy",
    desc: "가격이 비교적 저렴하고 1인 메뉴가 명확해 혼밥에 적합. 빠르게 한 끼를 해결해야 하는 학생에게 추천.",
    map_url:
      "https://map.naver.com/p/search/%ED%99%94%EC%9B%90%EB%A3%A8%20%EC%88%98%EC%9B%90%20%EC%9C%A8%EC%A0%84%EB%8F%99",
  },
  {
    campus: "율전",
    name: "정원",
    category: "중식",
    menu: "짜장면 6,500원 / 삼선간짜장 8,000원",
    difficulty: "easy",
    desc: "저렴한 가격대의 기본 중식 메뉴가 많아 가성비가 좋음. 공강 시간에 혼자 빠르게 식사하기 좋은 선택지.",
    map_url:
      "https://map.naver.com/p/search/%EC%A0%95%EC%9B%90%20%EC%88%98%EC%9B%90%20%EC%9C%A8%EC%A0%84%EB%8F%99%20%EC%A4%91%EA%B5%AD%EC%A7%91",
  },
  {
    campus: "율전",
    name: "홍성마라미방 성균관대점",
    category: "중식",
    menu: "마라탕 / 계란볶음밥 6,500원",
    difficulty: "easy",
    desc: "재료를 원하는 만큼 선택할 수 있어 취향 반영이 쉽고 학생 선호도가 높은 메뉴. 혼자 먹기에도 부담이 적어 추천.",
    map_url: "https://naver.me/FLyAZsiN",
  },
  {
    campus: "율전",
    name: "백사104",
    category: "중식",
    menu: "마라전골 / 볶음밥",
    difficulty: "hard",
    desc: "마라 계열을 좋아하는 학생에게 추천. 다만 저녁·술집 분위기가 강할 수 있어 점심 혼밥 룰렛에서는 우선순위를 낮게 설정하는 것이 적절함.",
    map_url:
      "https://map.naver.com/p/search/%EB%B0%B1%EC%82%AC104%20%EC%9C%A8%EC%A0%84%EB%8F%99",
  },
  {
    campus: "율전",
    name: "카마타케제면소",
    category: "일식",
    menu: "붓카케우동 / 냉우동 (약 8,000원대)",
    difficulty: "easy",
    desc: "우동 중심의 단일 식사 메뉴라 혼밥에 매우 적합. 빠르게 먹을 수 있고 학생 가격대라 공강 식사 추천도가 높음.",
    map_url:
      "https://map.naver.com/p/search/%EC%B9%B4%EB%A7%88%ED%83%80%EC%BC%80%EC%A0%9C%EB%A9%B4%EC%86%8C%20%EC%88%98%EC%9B%90",
  },
  {
    campus: "율전",
    name: "윤실장 초밥",
    category: "일식",
    menu: "연어초밥 2P 4,200원 / 활어초밥 2P 4,400원",
    difficulty: "medium",
    desc: "원하는 초밥을 골라 먹을 수 있어 예산 조절이 가능. 혼밥도 가능하지만 점심 피크 시간에는 대기 가능성을 고려해야 함.",
    map_url:
      "https://map.naver.com/p/search/%EC%9C%A4%EC%8B%A4%EC%9E%A5%EC%B4%88%EB%B0%A5%20%EC%9C%A8%EC%A0%84%EB%8F%99",
  },
  {
    campus: "율전",
    name: "면식당 수원성균관대점",
    category: "일식",
    menu: "돈코츠라멘 8,400원 / 마제소바 9,400원",
    difficulty: "easy",
    desc: "라멘·소바 등 1인 메뉴가 중심이라 혼밥에 적합. 가격도 1만 원 안팎으로 학생들이 이용하기 좋은 편.",
    map_url:
      "https://map.naver.com/p/search/%EB%A9%B4%EC%8B%9D%EB%8B%B9%20%EC%88%98%EC%9B%90%EC%84%B1%EA%B7%A0%EA%B4%80%EB%8C%80%EC%A0%90",
  },
  {
    campus: "율전",
    name: "키와마루아지",
    category: "일식",
    menu: "미라멘 7,500원 / 극라멘 8,500원",
    difficulty: "easy",
    desc: "라멘 전문점으로 혼자 앉기 좋은 좌석 구성이 장점. 빠른 식사와 혼밥을 동시에 만족시키기 좋은 후보.",
    map_url:
      "https://map.naver.com/p/search/%ED%82%A4%EC%99%80%EB%A7%88%EB%A3%A8%EC%95%84%EC%A7%80%20%EC%9C%A8%EC%A0%84%EB%8F%99",
  },
  {
    campus: "율전",
    name: "본찌돈까스 성대점",
    category: "일식",
    menu: "돈까스 9,000원 / 돈까스덮밥 8,500원",
    difficulty: "easy",
    desc: "양이 많고 가격이 비교적 합리적이라 학생 식사로 적합. 돈까스·덮밥은 혼자 먹기 편해 룰렛 추천 메뉴로 활용하기 좋음.",
    map_url:
      "https://map.naver.com/p/search/%EB%B3%B8%EC%B0%8C%EB%8F%88%EA%B9%8C%EC%8A%A4%20%EC%84%B1%EB%8C%80%EC%A0%90",
  },
  {
    campus: "율전",
    name: "소코아 수원성대점",
    category: "일식",
    menu: "에비후라이카레 약 13,000원 / 냉우동 약 13,000원",
    difficulty: "medium",
    desc: "가격은 다른 학생 식당보다 높은 편이지만 메뉴가 독특하고 분위기가 좋아 '오늘은 조금 특별하게' 같은 추천 조건에 적합.",
    map_url:
      "https://map.naver.com/p/search/%EC%86%8C%EC%BD%94%EC%95%84%20%EC%88%98%EC%9B%90%EC%84%B1%EB%8C%80%EC%A0%90",
  },
  {
    campus: "율전",
    name: "맥도날드 수원성대점",
    category: "패스트푸드",
    menu: "빅맥 세트 약 7,600원",
    difficulty: "easy",
    desc: "메뉴와 가격이 표준화되어 있고 주문·식사 시간이 예측 가능. 공강 시간이 짧을 때 가장 안정적인 선택지 중 하나.",
    map_url:
      "https://map.naver.com/p/search/%EB%A7%A5%EB%8F%84%EB%82%A0%EB%93%9C%20%EC%88%98%EC%9B%90%EC%84%B1%EB%8C%80%EC%A0%90",
  },
  {
    campus: "율전",
    name: "롯데리아 수원성균관대점",
    category: "패스트푸드",
    menu: "리아 불고기 단품 약 5,000원 / 세트 약 8,900원",
    difficulty: "easy",
    desc: "학생들에게 익숙하고 메뉴 선택이 쉬워 결정 피로가 적음. 빠르고 무난한 식사를 원하는 경우 추천.",
    map_url:
      "https://map.naver.com/p/search/%EB%A1%AF%EB%8D%B0%EB%A6%AC%EC%95%84%20%EC%88%98%EC%9B%90%EC%84%B1%EA%B7%A0%EA%B4%80%EB%8C%80%EC%A0%90",
  },
  {
    campus: "율전",
    name: "KFC 수원성균관대점",
    category: "패스트푸드",
    menu: "징거버거 / 치킨 세트",
    difficulty: "medium",
    desc: "치킨과 버거를 빠르게 먹을 수 있어 공강 식사에 적합. 일반 햄버거보다 치킨 메뉴를 선호하는 학생에게 추천. 다만 점심, 저녁 시간에 많이 붐빔.",
    map_url:
      "https://map.naver.com/p/search/KFC%20%EC%88%98%EC%9B%90%EC%84%B1%EA%B7%A0%EA%B4%80%EB%8C%80%EC%A0%90",
  },
  {
    campus: "율전",
    name: "맘스터치 수원성균관대점",
    category: "패스트푸드",
    menu: "싸이버거 단품 약 5,200원 / 세트 약 7,300원",
    difficulty: "easy",
    desc: "양이 많고 가격이 비교적 저렴해 학생 만족도가 높은 편. 혼밥·포장 모두 편리하여 룰렛 후보로 적합.",
    map_url:
      "https://map.naver.com/p/search/%EB%A7%98%EC%8A%A4%ED%84%B0%EC%B9%98%20%EC%88%98%EC%9B%90%EC%84%B1%EA%B7%A0%EA%B4%80%EB%8C%80%EC%A0%90",
  },
  {
    campus: "율전",
    name: "버거스올마이티 수원성균대점",
    category: "패스트푸드",
    menu: "수제버거류 (약 10,000원대)",
    difficulty: "easy",
    desc: "일반 프랜차이즈보다 수제버거 느낌이 강해 맛을 우선하는 날 추천. 다만 가격은 기본 패스트푸드보다 높은 편.",
    map_url: "https://naver.me/GRoZjTIL",
  },
  {
    campus: "율전",
    name: "써브웨이 성균관대 인근점",
    category: "패스트푸드",
    menu: "샌드위치류 (약 6,000~10,000원대)",
    difficulty: "medium",
    desc: "혼밥과 포장이 모두 편하고 재료를 직접 선택할 수 있어 취향 반영이 쉬움. 가볍게 먹고 싶은 날 추천하기 좋음. 점심시간에 많이 붐빔.",
    map_url:
      "https://map.naver.com/p/search/%EC%8D%A8%EB%B8%8C%EC%9B%A8%EC%9D%B4%20%EC%84%B1%EA%B7%A0%EA%B4%80%EB%8C%80%20%EC%88%98%EC%9B%90",
  },
  {
    campus: "율전",
    name: "롤링파스타 수원성균관대점",
    category: "양식",
    menu: "청양 불고기 파스타 9,500원 / 토마토 파스타 7,900원",
    difficulty: "easy",
    desc: "1만 원 이하 파스타 메뉴가 많아 학생 부담이 적고, 1인석과 혼밥 이용 후기가 있어 공강 시간에 빠르게 식사하기 좋음. 가성비를 우선할 때 추천.",
    map_url:
      "https://map.naver.com/p/search/%EB%A1%A4%EB%A7%81%ED%8C%8C%EC%8A%A4%ED%83%80%20%EC%88%98%EC%9B%90%EC%84%B1%EA%B7%A0%EA%B4%80%EB%8C%80%EC%A0%90",
  },
  {
    campus: "율전",
    name: "아늑",
    category: "양식",
    menu: "스파이시 까르보나라 8,900원 / 해산물 스파이시 올리오 8,500원",
    difficulty: "easy",
    desc: "파스타 대부분이 1만 원 이하로 가격 부담이 적고 메뉴 선택 폭이 넓음. 가볍게 양식을 먹고 싶은 학생에게 적합하며 가성비가 좋은 편.",
    map_url:
      "https://map.naver.com/p/search/%EC%95%84%EB%8A%91%20%EC%88%98%EC%9B%90%20%EC%9C%A8%EC%A0%84%EB%8F%99",
  },
  {
    campus: "율전",
    name: "몽키키친",
    category: "양식",
    menu: "상하이 파스타 12,000원 / 통베이컨 토마토파스타 11,000원",
    difficulty: "easy",
    desc: "혼밥석부터 단체석까지 마련되어 있어 혼자 이용하기 편리함. 메뉴가 다양하고 특히 상하이 파스타에 대한 평가가 좋아 맛과 혼밥 편의성을 함께 고려할 때 추천.",
    map_url:
      "https://map.naver.com/p/search/%EB%AA%BD%ED%82%A4%ED%82%A4%EC%B9%9C%20%EC%9C%A8%EC%A0%84%EB%8F%99",
  },
  {
    campus: "율전",
    name: "도레미파스타",
    category: "양식",
    menu: "할라피뇨 로제 10,900원 / 매운치킨 크림파스타 10,900원",
    difficulty: "easy",
    desc: "키오스크 주문 방식으로 메뉴 선택과 주문이 간편하고 혼밥 이용이 가능함. 아담하고 깔끔한 분위기로 혼자 파스타를 먹고 싶은 날 추천.",
    map_url:
      "https://map.naver.com/p/search/%EB%8F%84%EB%A0%88%EB%AF%B8%ED%8C%8C%EC%8A%A4%ED%83%80%20%EC%88%98%EC%9B%90%20%EC%9C%A8%EC%A0%84%EB%8F%99",
  },
  {
    campus: "율전",
    name: "오스테리아 우노",
    category: "양식",
    menu: "봉골레 파스타 19,000원 / 새우 비스큐 파스타 21,000원",
    difficulty: "easy",
    desc: "가격대는 학생 식당보다 높은 편이지만 음식의 완성도와 분위기에 대한 평가가 좋음. 평소보다 제대로 된 이탈리안 메뉴를 먹고 싶은 날 추천.",
    map_url:
      "https://map.naver.com/p/search/%EC%98%A4%EC%8A%A4%ED%85%8C%EB%A6%AC%EC%95%84%20%EC%9A%B0%EB%85%B8%20%EC%9C%A8%EC%A0%84%EB%8F%99",
  },
  {
    campus: "율전",
    name: "작은바와 서양면집 성대역본점",
    category: "양식",
    menu: "알리오올리오 7,500원 / 감바스파스타 10,500원",
    difficulty: "easy",
    desc: "파스타 종류가 다양하고 비교적 저렴한 메뉴부터 선택할 수 있음. 점심에는 간단한 식사가 가능하고 저녁에는 분위기 있는 식사도 가능해 선택 폭이 넓음.",
    map_url:
      "https://map.naver.com/p/search/%EC%9E%91%EC%9D%80%EB%B0%94%EC%99%80%20%EC%84%9C%EC%96%91%EB%A9%B4%EC%A7%91%20%EC%84%B1%EB%8C%80%EC%97%AD%EB%B3%B8%EC%A0%90",
  },

  {
    campus: "명륜",
    name: "성균관감자탕",
    category: "한식",
    menu: "뼈다귀해장국 9,000원 / 김치짜글이 9,000원",
    difficulty: "easy",
    desc: "성균관대 정문 인근에서 1인 해장국 메뉴로 빠르게 식사하기 좋음. 국물 메뉴라 포만감이 높고 혼밥 난이도가 낮아 짧은 공강에 추천.",
    map_url: "https://naver.me/x2jvLNBK",
  },
  {
    campus: "명륜",
    name: "삼삼오오",
    category: "한식",
    menu: "야채비빔밥 6,500원 / 김치찌개 6,500원 / 오삼불고기 2인 15,000원",
    difficulty: "easy",
    desc: "명륜 학생 상권의 대표적인 가성비 한식집. 비빔밥·찌개처럼 1인 주문이 쉬운 메뉴가 있어 정문에서 빠르게 이동해 혼밥하기 좋음.",
    map_url: "https://naver.me/5Rh0qrlg",
  },
  {
    campus: "명륜",
    name: "뽀글뚝배기냠냠비빔밥",
    category: "한식",
    menu: "제육+비빔밥 7,000원 / 차돌된장+비빔밥 7,000원",
    difficulty: "easy",
    desc: "키오스크 주문 후 약 5~10분 안에 음식이 나오는 편이며 가격이 저렴함. 혼자 방문해도 부담이 적어 공강 점심용으로 특히 적합.",
    map_url: "https://naver.me/5iTo4X9f",
  },
  {
    campus: "명륜",
    name: "한국관",
    category: "한식",
    menu: "된장찌개 9,000원 / 산채비빔밥 10,000원 / 돌솥비빔밥 10,000원",
    difficulty: "easy",
    desc: "정문 주변에서 비빔밥·찌개 등 익숙한 한식을 선택하기 좋음. 메뉴가 다양해 룰렛 결과로 나와도 실패 확률이 낮은 안정적인 후보.",
    map_url: "https://naver.me/xQe4xQah",
  },
  {
    campus: "명륜",
    name: "송현식당",
    category: "한식",
    menu: "백반 / 서울식 불고기 (약 7,000~10,000원대)",
    difficulty: "easy",
    desc: "성균관로에 있어 정문 기준 접근성이 좋고 집밥 스타일의 백반을 먹을 수 있음. 혼자 먹기 불편하지 않다는 후기가 있어 학생 혼밥용으로 추천.",
    map_url: "https://naver.me/x7nW91XW",
  },
  {
    campus: "명륜",
    name: "밀가",
    category: "한식",
    menu: "백반 6,000원 / 제육덮밥 7,000원 / 고추장비빔밥 8,000원",
    difficulty: "easy",
    desc: "6천 원부터 시작하는 저렴한 메뉴가 강점. 화려한 식당보다는 가정식 느낌을 선호하고 식비를 아끼고 싶은 학생에게 추천.",
    map_url: "https://naver.me/GEXHhmZV",
  },
  {
    campus: "명륜",
    name: "세아 간짜장전문점",
    category: "중식",
    menu: "간짜장 8,000원 / 차돌짬뽕 10,500원 / 마늘탕수육 17,000원",
    difficulty: "easy",
    desc: "성균관로 20에 있어 정문 접근성이 매우 좋음. 짜장·짬뽕처럼 1인 메뉴가 명확하고 가격도 학생이 이용하기 적당해 점심 혼밥 우선 추천.",
    map_url: "https://naver.me/GbDnf0fM",
  },
  {
    campus: "명륜",
    name: "저팔계식당",
    category: "중식",
    menu: "마라탕 14,900원 / 1인식사+꿔바로우 세트 21,800원",
    difficulty: "easy",
    desc: "혼자 먹을 수 있는 세트와 마라탕 메뉴가 있어 프로젝트 취지와 잘 맞음. 정문에서 명륜길 방향으로 접근 가능하고 중국식 메뉴 선택 폭이 넓음.",
    map_url: "https://naver.me/5LHGlgam",
  },
  {
    campus: "명륜",
    name: "가부 혜화점",
    category: "중식",
    menu: "짜장면 약 7,000원대 / 짬뽕 약 10,000원대",
    difficulty: "easy",
    desc: "점심 영업과 혼밥 이용 정보가 확인되며 짬뽕 국물과 식재료 평가가 좋은 편. 정문에서 혜화 방향으로 이동할 때 선택하기 좋은 중식 후보.",
    map_url: "https://naver.me/FN7sHfj2",
  },
  {
    campus: "명륜",
    name: "진공푸",
    category: "중식",
    menu: "짜장·짬뽕·탕수육 세트 약 10,000원대",
    difficulty: "easy",
    desc: "세트메뉴 가성비가 좋고 음식이 비교적 빨리 나온다는 평가가 있음. 짧은 공강에 중식을 든든하게 먹고 싶을 때 추천.",
    map_url: "https://naver.me/GNWkuB4g",
  },
  {
    campus: "명륜",
    name: "대빵우육면 본점",
    category: "중식",
    menu: "우육면 약 10,000원대",
    difficulty: "easy",
    desc: "성균관대 옆에서 점심 이용 후기가 확인되는 우육면집. 일반 짜장면보다 색다른 중식을 원할 때 좋고 혼자 한 그릇 식사하기 편함.",
    map_url: "https://naver.me/F1rYBwio",
  },
  {
    campus: "명륜",
    name: "의원상",
    category: "중식",
    menu: "량피 / 쏸라펀 (약 8,000~12,000원대)",
    difficulty: "easy",
    desc: "명륜3가에 위치한 중국 특색요리 식당. 향신료를 좋아하는 학생에게 적합하며 1인 면·분식형 메뉴가 있어 혼밥 후보로 활용하기 좋음.",
    map_url: "https://naver.me/GxkiT34z",
  },
  {
    campus: "명륜",
    name: "쇼타돈부리",
    category: "일식",
    menu: "돈부리·카레덮밥 약 7,000~9,000원대",
    difficulty: "easy",
    desc: "성대 학생들이 자주 찾는 덮밥집으로 1인 1메뉴 구조라 혼밥하기 편함. 가격대가 비교적 낮아 가성비 중심 추천에 적합.",
    map_url: "https://naver.me/FDnqIJTP",
  },
  {
    campus: "명륜",
    name: "물결식당",
    category: "일식",
    menu: "닭고기덮밥 / 고등어덮밥 (약 10,000원대)",
    difficulty: "easy",
    desc: "성균관로 25-9에 위치해 정문과 가까운 편. 덮밥류 중심이라 혼자 먹기 편하며 조용한 분위기를 선호하는 학생에게 추천.",
    map_url: "https://naver.me/G9r5Fsa8",
  },
  {
    campus: "명륜",
    name: "혼또카레",
    category: "일식",
    menu: "야끼카레 13,800원 / 치킨카레 13,800원 / 삿포로 스프카레 16,800원",
    difficulty: "easy",
    desc: "바 좌석과 1인 카레 메뉴가 있어 혼밥하기 좋음. 기본 학생식보다 가격은 높지만 카레를 확실히 먹고 싶은 날 추천하기 좋은 후보.",
    map_url: "https://naver.me/x0UErrbv",
  },
  {
    campus: "명륜",
    name: "맛의정원",
    category: "일식",
    menu: "베이컨 버섯 오므라이스 약 14,000원",
    difficulty: "easy",
    desc: "혼밥하기 좋은 일본식 가정식이라는 평가가 있으며 음식·응대 만족도가 높음. 가격보다 맛과 분위기를 조금 더 중시할 때 추천.",
    map_url: "https://naver.me/FA2xqBEI",
  },
  {
    campus: "명륜",
    name: "히메시야 혜화직영점",
    category: "일식",
    menu: "카츠동 10,000원 / 에비 카레 9,500원 / 우동 6,500원",
    difficulty: "easy",
    desc: "돈부리·카레·우동 등 혼자 주문하기 좋은 메뉴가 많아 선택 장애를 줄이기 좋음. 메뉴 가격 폭도 넓어 예산별 추천에 활용 가능.",
    map_url: "https://naver.me/GQ1ludcv",
  },
  {
    campus: "명륜",
    name: "행복은간장밥 성균관대점",
    category: "일식",
    menu: "순살 꽃게장 덮밥 10,900원 / 우삼겹 덮밥 10,900원 / 간장 육회 덮밥 10,900원",
    difficulty: "easy",
    desc: "대표 메뉴 가격이 동일해 룰렛용 데이터로 쓰기 편하고 덮밥 중심이라 혼밥 난이도가 낮음. 빠르게 한 끼를 결정해야 할 때 추천.",
    map_url: "https://naver.me/x67ylWNZ",
  },
  {
    campus: "명륜",
    name: "플라이팬",
    category: "양식",
    menu: "크림새우베이컨스파게티 / 치즈오븐떡볶이 (약 10,000원 안팎)",
    difficulty: "easy",
    desc: "학교 근처 학생 상권의 소규모 파스타집으로 가격이 비교적 저렴하고 혼밥 이용 후기가 있음. 가볍게 양식을 먹고 싶을 때 적합.",
    map_url: "https://naver.me/x8tnYN16",
  },
  {
    campus: "명륜",
    name: "노말키친",
    category: "양식",
    menu: "파스타·피자 약 10,000~20,000원대",
    difficulty: "hard",
    desc: "성균관로6길에 있어 정문 기준 도보권이며 파스타와 피자 평가가 좋은 편. 혼밥보다는 여유 있는 점심이나 2인 식사에도 잘 맞음.",
    map_url: "https://naver.me/5mI0rptN",
  },
  {
    campus: "명륜",
    name: "라온섬",
    category: "양식",
    menu: "프렌치토스트 플래터 / 베이글·브런치류 (약 6,000~13,000원대)",
    difficulty: "easy",
    desc: "성균관대 앞 브런치 식당으로 정문 접근성이 좋고 가벼운 1인 식사가 가능함. 밥류가 부담스러운 날 대체 메뉴로 추천.",
    map_url: "https://naver.me/57VZucXL",
  },
  {
    campus: "명륜",
    name: "맥덕스",
    category: "양식",
    menu: "피자류 (약 10,000~20,000원대)",
    difficulty: "hard",
    desc: "성균관대학교 정문 왼편, 정문 약 1분 거리로 위치 장점이 매우 큼. 피자 특성상 2인 이상에 더 잘 맞아 혼밥 룰렛에서는 우선순위를 낮추는 것이 적절함.",
    map_url: "https://naver.me/5CW7BKAr",
  },
  {
    campus: "명륜",
    name: "도스타코스 성균관대점",
    category: "양식",
    menu: "알빠스톨따꼬 10,000원 / 고기부리또 10,500원 / 닭고기따꼬 11,000원",
    difficulty: "easy",
    desc: "타코·부리또는 1인 식사와 포장이 모두 쉬워 짧은 공강에 활용하기 좋음. 파스타 외의 양식을 원할 때 선택지를 넓혀주는 후보.",
    map_url: "https://naver.me/FzSZzVqS",
  },
  {
    campus: "명륜",
    name: "벅벅",
    category: "패스트푸드",
    menu: "벅벅 / 더블벅 / 해쉬벅 (세트 약 12,000~14,000원대)",
    difficulty: "easy",
    desc: "성균관대 학생 상권의 대표 수제버거집. 1인 주문이 쉽고 포만감이 높아 맛을 우선하는 빠른 식사 옵션으로 추천.",
    map_url: "https://naver.me/5HkatR9B",
  },
  {
    campus: "명륜",
    name: "써브웨이 서울성균관대점",
    category: "패스트푸드",
    menu: "15cm 샌드위치·샐러드 (약 7,000~13,000원대)",
    difficulty: "easy",
    desc: "600주년기념관 지하1층에 위치하며 학교 공식 시설 안내에서 현재 운영이 확인됨. 혼밥·포장이 편하고 식사 시간을 예측하기 쉬움.",
    map_url: "https://naver.me/FN7cSfAN",
  },
  {
    campus: "명륜",
    name: "한솥도시락 성균관대앞점",
    category: "패스트푸드",
    menu: "열무 감초고추장 비빔밥 6,200원 / 왕카레돈까스덮밥 7,900원",
    difficulty: "easy",
    desc: "정문·성대입구 생활권에서 포장과 혼밥이 매우 편한 실용적인 선택지. 가격이 낮고 메뉴가 빨리 나와 공강 식사 KPI와 잘 맞음.",
    map_url: "https://naver.me/xP8rVomo",
  },
  {
    campus: "명륜",
    name: "샐러디 성대입구점",
    category: "패스트푸드",
    menu: "바베큐닭다리살 곡물랩 8,400원 / 샌드위치 세트 약 9,900원",
    difficulty: "easy",
    desc: "성대입구 쪽에서 혼밥하기 편한 샐러드·랩 전문점. 가볍고 건강한 메뉴가 필요할 때 추천하며 포장도 쉬움.",
    map_url: "https://naver.me/F2ZdNkap",
  },
  {
    campus: "명륜",
    name: "롯데리아 혜화점",
    category: "패스트푸드",
    menu: "리아 불고기 세트 약 8,000~9,000원대",
    difficulty: "easy",
    desc: "정문에서 혜화 방향으로 이동해야 하지만 메뉴가 표준화되어 선택과 주문이 빠름. 익숙하고 실패 확률이 낮은 패스트푸드 옵션.",
    map_url: "https://naver.me/GFByXVJO",
  },
]

export const restaurants: Restaurant[] = RAW.map((r) => ({
  campus: r.campus,
  name: r.name,
  category: r.category,
  menu: r.menu,
  level: DIFFICULTY_TO_LEVEL[r.difficulty],
  desc: r.desc,
  mapUrl: r.map_url,
}))

export function getByCampus(campus: Campus): Restaurant[] {
  return restaurants.filter((r) => r.campus === campus)
}
